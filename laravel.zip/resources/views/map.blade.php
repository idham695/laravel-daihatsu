@extends('layout/header')
@section('title', "Map")
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15842.361142284264!2d107.58104159999999!3d-6.9394709!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68e8ae1da97a77%3A0xd6c00e78478af9b7!2sKredit%20Daihatsu%20Bandung!5e0!3m2!1sid!2sid!4v1584602168065!5m2!1sid!2sid" width="600" height="450" frameborder="0" style="border:0; width:100%; margiin-top:10px;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
@include('layout/footer')
