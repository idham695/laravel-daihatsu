        <div class="footer" id="footer">
                <p>&copy; 2020 all right reserved by Daihatsu Tunas</p>
        </div>
    </div>
</div>