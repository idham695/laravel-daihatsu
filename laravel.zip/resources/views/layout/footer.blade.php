</body>
    <script src="{{ URL::asset('js/jquery-3.4.1.js') }}"></script>
    <script src="{{ URL::asset('js/popper.min.js') }}"></script>
    <script src="{{ URL::asset('js/bootstrap.js') }}"></script>
    <script src="{{ URL::asset('js/js-cloudimage-360-view.min.js') }}"></script>
    <script src="{{ URL::asset('js/script.js') }}"></script>
</html>