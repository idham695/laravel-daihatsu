        <div class="footer" id="footer">
                <p>&copy; 2020 all right reserved by Daihatsu Tunas</p>
        </div>
    </div>
</div><?php /**PATH C:\laravel\resources\views/layout/footercomp.blade.php ENDPATH**/ ?>