<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('fontawesome/css/fontawesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('fontawesome/css/solid.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('fontawesome/css/brands.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/style2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/image.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/type.css')); ?>">
<body>
<?php /**PATH C:\laravel\resources\views/layout/header.blade.php ENDPATH**/ ?>