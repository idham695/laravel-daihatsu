<div class="feature">
    <h3>Fitur <?php echo e($types->product->name); ?> <?php echo e($types->type); ?></h3>
    <ul class="nav nav-tabs tab">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#Eksterior">Eksterior</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#hiburan">Hiburan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#keamanan">Keamanan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#keselamatan">Keselamatan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#kenyamanan">Kenyamanan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#lain">lain - Lain</a>
                </li>
    </ul>
    <div class="tab-content content">
                    <div class="tab-pane active" id="Eksterior">
                        <?php $__currentLoopData = $types->eksterior; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eksterior): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <table class="table table-lg bg-light">
                                        <thead>
                                            <tr>
                                                <th colspan="2">Eksterior</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Adjustable Headlight</td>
                                                <td><?php echo e($eksterior->adjutableHeadlight); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Lampu Kabut Depan</td>
                                                <td><?php echo e($eksterior->lampuKabutDepan); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Kaca Spion Elektrik</td>
                                                <td><?php echo e($eksterior->kacaSpionElektrik); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Kaca Spion Luar Manual</td>
                                                <td><?php echo e($eksterior->kacaSpionLuarManual); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Wiper Otomatis</td>
                                                <td><?php echo e($eksterior->wiperOtomatis); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Wiper Kaca Belakang</td>
                                                <td><?php echo e($eksterior->wiperKacaBelakang); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Cover Velg</td>
                                                <td><?php echo e($eksterior->coverVelg); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Velg Alloy</td>
                                                <td><?php echo e($eksterior->velgAlloy); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Anthena Elektrik</td>
                                                <td><?php echo e($eksterior->anthenaElektrik); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Spoiler Belakang</td>
                                                <td><?php echo e($eksterior->spoilerBelakang); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Atap Convertible</td>
                                                <td><?php echo e($eksterior->atapConvertible); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Roof Rack</td>
                                                <td><?php echo e($eksterior->roofRack); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Sun Roof</td>
                                                <td><?php echo e($eksterior->sunRoof); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Pijakan Samping</td>
                                                <td><?php echo e($eksterior->pijakanSamping); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Lampu Sein</td>
                                                <td><?php echo e($eksterior->lampuSein); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Anthena Terpadu</td>
                                                <td><?php echo e($eksterior->anthenaTerpadu); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Grille Krom</td>
                                                <td><?php echo e($eksterior->grilleKrom); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Roof Rail</td>
                                                <td><?php echo e($eksterior->roofRail); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Jenis Rem Belakang</td>
                                                <td><?php echo e($eksterior->jenisRemBelakang); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Jenis Rem Depan</td>
                                                <td><?php echo e($eksterior->jenisRemDepan); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="tab-pane fade" id="hiburan">
                        <?php $__currentLoopData = $types->hiburan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hiburan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <table class="table table-lg bg-light">
                                <thead>
                                    <tr>
                                        <th colspan="2">Hiburan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Layar Sentuh</td>
                                        <td><?php echo e($hiburan->layarSentuh); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Sistem Navigasi</td>
                                        <td><?php echo e($hiburan->sistemNavigasi); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Sambungan Bluetooth</td>
                                        <td><?php echo e($hiburan->sambunganBluetooth); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Soket USB</td>
                                        <td><?php echo e($hiburan->soketUSB); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pemutar CD</td>
                                        <td><?php echo e($hiburan->pemutarCD); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pemutar DVD</td>
                                        <td><?php echo e($hiburan->pemutarDVD); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Speaker Depan</td>
                                        <td><?php echo e($hiburan->speakerDepan); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Speaker Belakang</td>
                                        <td><?php echo e($hiburan->speakerBelakang); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Audio 2DIN</td>
                                        <td><?php echo e($hiburan->audio2DIN); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Perintah Suara</td>
                                        <td><?php echo e($hiburan->perintahSuara); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="tab-pane fade" id="keamanan">
                    <?php $__currentLoopData = $types->keamanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keamanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <table class="table table-lg bg-light">
                                <thead>
                                    <tr>
                                        <th colspan="2">Keamanan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Smart Access</td>
                                        <td><?php echo e($keamanan->smartAccess); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Power Door Locks</td>
                                        <td><?php echo e($keamanan->powerDoorLocks); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Anti Theft Device</td>
                                        <td><?php echo e($keamanan->antiTheftDevice); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Alarm Mobil</td>
                                        <td><?php echo e($keamanan->alarmMobil); ?></td>
                                    </tr>
                                </tbody>
                    </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="tab-pane fade" id="kenyamanan">
                    <?php $__currentLoopData = $types->kenyamanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kenyamanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <table class="table table-lg bg-light">
                                <thead>
                                    <tr>
                                        <th colspan="2">Kenyamanan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>AC</td>
                                        <td><?php echo e($kenyamanan->AC); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Power Window</td>
                                        <td><?php echo e($kenyamanan->powerWindow); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Power Steering</td>
                                        <td><?php echo e($kenyamanan->powerSteering); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pemanas</td>
                                        <td><?php echo e($kenyamanan->pemanas); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Glove Box</td>
                                        <td><?php echo e($kenyamanan->gloveBox); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Engine Start</td>
                                        <td><?php echo e($kenyamanan->engineStart); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Adjustable Sheet</td>
                                        <td><?php echo e($kenyamanan->adjustableSheet); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Kursi Heater Depan</td>
                                        <td><?php echo e($kenyamanan->kursiHeaterDepan); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Kursi Heater Belakang</td>
                                        <td><?php echo e($kenyamanan->kursiHeaterBelakang); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Spion Lipat</td>
                                        <td><?php echo e($kenyamanan->spionLipat); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Follow Me Home HeadLamps</td>
                                        <td><?php echo e($kenyamanan->followMeHomeHeadLamps); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Steering Wheel Gearshift Paddle</td>
                                        <td><?php echo e($kenyamanan->steeringWheel); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Lingkar Kemudi dengan tombol MultiFungsi</td>
                                        <td><?php echo e($kenyamanan->lingkarKemudi); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Cruise Control</td>
                                        <td><?php echo e($kenyamanan->cruiseControl); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Kursi Lipat Belakang</td>
                                        <td><?php echo e($kenyamanan->kursiLipatBelakang); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pembuka Bagasi</td>
                                        <td><?php echo e($kenyamanan->pembukaBagasi); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Lampu Pengingat< Jumlah Bahan Bakar</td>
                                        <td><?php echo e($kenyamanan->lampuPengingat); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Headrest Kursi Belakang</td>
                                        <td><?php echo e($kenyamanan->headrestKursi); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Arm Rest Belakang Tengah</td>
                                        <td><?php echo e($kenyamanan->armRest); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Cup Holder - Depan</td>
                                        <td><?php echo e($kenyamanan->cupHolder); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Lumbar Support</td>
                                        <td><?php echo e($kenyamanan->lumbarSupport); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Bottle Holder</td>
                                        <td><?php echo e($kenyamanan->bottleHolder); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Lampu Bagasi</td>
                                        <td><?php echo e($kenyamanan->lampuBagasi); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Meja Lipat Belakang</td>
                                        <td><?php echo e($kenyamanan->mejaLipatBelakang); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Arm Rest Konsol Tengah</td>
                                        <td><?php echo e($kenyamanan->armRestTengah); ?></td>
                                    </tr>
                                </tbody>
                    </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="tab-pane fade" id="keselamatan">
                    <?php $__currentLoopData = $types->keselamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keselamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <table class="table table-lg bg-light">
                                <thead>
                                    <tr>
                                        <th colspan="2">Keselamatan </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Air Bag Depan</td>
                                        <td><?php echo e($keselamatan->airbagDepan); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Air Bag Belakang</td>
                                        <td><?php echo e($keselamatan->airbagBelakang); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Child Safety</td>
                                        <td><?php echo e($keselamatan->childSafety); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Kantong Udara</td>
                                        <td><?php echo e($keselamatan->kantongUdara); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Air Bag Samping</td>
                                        <td><?php echo e($keselamatan->airbagSamping); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Vehicle Stability</td>
                                        <td><?php echo e($keselamatan->vehicleStability); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Sabuk Pengaman</td>
                                        <td><?php echo e($keselamatan->sabukPengaman); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pengingat Pengaman</td>
                                        <td><?php echo e($keselamatan->pengingatPengaman); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Kamera Belakang</td>
                                        <td><?php echo e($keselamatan->kameraBelakang); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Sensor Parkir</td>
                                        <td><?php echo e($keselamatan->sensorParkir); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Engine Check</td>
                                        <td><?php echo e($keselamatan->engineCheck); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pengukur Tekanan</td>
                                        <td><?php echo e($keselamatan->pengukurTekanan); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pelindung Benturan</td>
                                        <td><?php echo e($keselamatan->pelindungBenturan); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pengingat Pintu</td>
                                        <td><?php echo e($keselamatan->pengingatPintu); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Kontrol Traksi</td>
                                        <td><?php echo e($keselamatan->kontrolTraksi); ?></td>
                                    </tr>
                                </tbody>
                    </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="tab-pane fade" id="lain">
                    <?php $__currentLoopData = $types->lain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <table class="table table-lg bg-light">
                                <thead>
                                    <tr>
                                        <th colspan="2">Lain - Lain</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Tachometer</td>
                                        <td><?php echo e($lain->tachometer); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Electronic Multi Tripmeter</td>
                                        <td><?php echo e($lain->electronicMultiTripmeter); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Jok Dilapisi Kulit</td>
                                        <td><?php echo e($lain->jokDilapisiKulit); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Lapisan Berbahan kain</td>
                                        <td><?php echo e($lain->lapisanBerbahanKain); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Stir Berbalut Kulit</td>
                                        <td><?php echo e($lain->stirBerbalutKulit); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Temperatur Udara Luar</td>
                                        <td><?php echo e($lain->temperaturUdaraLuar); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Odometer Digital</td>
                                        <td><?php echo e($lain->odometerDigital); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pengaturan Kursi Elektrik</td>
                                        <td><?php echo e($lain->pengaturanKursiElektrik); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Tangki Bahan Bakar</td>
                                        <td><?php echo e($lain->tangkiBahanBakar); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Jenis Lampu Depan</td>
                                        <td><?php echo e($lain->jenisLampuDepan); ?></td>
                                    </tr>
                                </tbody>
                    </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
        </div>
</div><?php /**PATH C:\laravel\resources\views/layout/type/spesification.blade.php ENDPATH**/ ?>