<?php $__env->startSection('title', "Dashboard"); ?>
<?php echo $__env->make('layout/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="product" id="product">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 search">
                        <form action="searchProduct" method="POST">
                        <?php echo e(csrf_field()); ?>

                            <div class="input-group mt-3">
                                <input type="text" class="form-control" placeholder="Cari Merk Mobil..." name="cari">
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="submit">Cari</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 d-flex">
                        <div class="card flex-fill">
                            <img src="img/<?php echo e($p->image); ?>" alt="" class="card-img-top">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($p->name); ?></h5>
                                <p class="card-text">Rp. <?php echo e(number_format($p->min_price, 3)); ?>.000 - Rp. <?php echo e(number_format($p->max_price, 3)); ?>.000</p>
                                <a href="/product/<?php echo e($p->id); ?>" class="btn btn-primary u">View Product</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row promo">
                    <div class="col-6 col-sm-3 ">
                    <a href="https://api.whatsapp.com/send?phone=+628881260028" class="info u">Promo Menarik</a>
                    </div>
                    <div class="col-6 col-sm-3">
                    <a href="https://api.whatsapp.com/send?phone=+628881260028" class="info u">Informasi Harga</a>
                    </div>
                    <div class="col-6 col-sm-3">
                    <a href="https://api.whatsapp.com/send?phone=+628881260028"  class="info u">Informasi DP</a>
                    </div>
                    <div class="col-6 col-sm-3">
                    <a href="https://api.whatsapp.com/send?phone=+628881260028"  class="info u">Informasi Angsuran</a>
                    </div>
                </div>
            </div>
        </div>
<?php echo $__env->make('layout/icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout/footercomp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\resources\views/index.blade.php ENDPATH**/ ?>