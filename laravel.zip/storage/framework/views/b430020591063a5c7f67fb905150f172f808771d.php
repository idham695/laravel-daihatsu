<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<nav class="navbar fixed-top navbar-expand-lg navbar-light" id="navbar" >
            <div class="container">
                <div onclick="openNav()" id="main" class="main">&#9776;</div>
                <a class="navbar-brand u" href="/"><img src="<?php echo e(URL::asset('img/unnamed.png')); ?>" alt=""></a>
                <div class="nav ml-auto">
                    <a href="/map" class="feather u"><i class="fas fa-map-marker-alt"></i></a>
                </div>
            </div>
</nav>
<div id="container" onclick="closeNav()">
<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\resources\views/layout/navbar.blade.php ENDPATH**/ ?>