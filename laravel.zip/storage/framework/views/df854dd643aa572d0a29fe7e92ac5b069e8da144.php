<div class="sidenav" id="sidenav">
    <div class="closebtn" onclick="closeNav()">&times;</div>
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div onclick="openSub(<?php echo e($item->id); ?>)" class="insidenav" id="insidenav"><?php echo e($item->name); ?>

        <span class="iconsidebar" id="iconplus"><i id="icon<?php echo e($item->id); ?>" class="fas fa-plus"></i></span>
        </div>
            <div class="subsidebar" id='subsidebar<?php echo e($item->id); ?>'>
                <?php $__currentLoopData = $item->type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/type/<?php echo e($typeItem->id); ?>" class="link"> <?php echo e($item->name); ?> <?php echo e($typeItem->type); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\laravel\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>