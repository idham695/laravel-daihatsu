<?php $__env->startSection('title', "Search"); ?>
<div class="container">
    <div class="row">
        <div class="col text-left">
            <a href="/" class="back"><i class="fas fa-arrow-left"></i></a>
        </div>
    </div>
</div>
<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\resources\views/search.blade.php ENDPATH**/ ?>