</body>
    <script src="<?php echo e(URL::asset('js/jquery-3.4.1.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('js/js-cloudimage-360-view.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('js/script.js')); ?>"></script>
</html><?php /**PATH C:\laravel\resources\views/layout/footer.blade.php ENDPATH**/ ?>