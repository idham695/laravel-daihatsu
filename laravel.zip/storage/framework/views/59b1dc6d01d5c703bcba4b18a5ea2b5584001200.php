<?php $__env->startSection('title', "Dashboard"); ?>
<?php echo $__env->make('layout/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="banner">
    <img src="<?php echo e(asset('/img/'. $products->banner)); ?>" alt="">
    <div class="container">
        <div class="banner-teks">
            <h2><?php echo e($products->name); ?></h2>
        </div>
        <!-- <div class="banner-price">
            <h5>Rp. <?php echo e($products->min_price); ?>0.000 - Rp. <?php echo e($products->max_price); ?>0.000</h5>
        </div> -->
        <div class="banner-button">
                    <a href="https://api.whatsapp.com/send?phone=+628881260028" class="qta u">Promo Menarik</a>
                    <a href="/product/image/<?php echo e($products->id); ?>" class="qta u">Detail Gambar</a>
        </div>
    </div>
</div>
<div class="products">
    <div class="container">
        <div class="informasi">
            <!-- <?php $__currentLoopData = $products->type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($type->type); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
            <h1>Informasi Terkait <?php echo e($products->name); ?></h1>
            <p class="a">
                <?php echo e($products->desc); ?>

            </p>
        </div>
    </div>
</div>
<div class="kelebihan">
    <div class="container">
        <h1><?php echo e($products->name); ?> : Dari para ahli</h1>
        <div class="plus-minus">
            <div class="row">
                <div class="col-md-4 bg-hijau">
                    <h3>Kelebihan <?php echo e($products->name); ?> </h3>
                    <ul>
                        <?php $__currentLoopData = $products->plus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelebihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="hijau"><?php echo e($kelebihan->kelebihan); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="col-md-6 offset-md-1 color">
                    <h3>Warna Daihatsu <?php echo e($products->name); ?></h3>
                    <p><?php echo e($products->name); ?> tersedia dalam  <?php $__currentLoopData = $c; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($color->color_count); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  warna yang berbeda yaitu <?php $__currentLoopData = $products->color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($color->color_name); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </p>
                        <div class="product-color">
                            <div class="d-flex flex-row flex-nowrap">
                                <div class="colorbox">
                                    <?php $__currentLoopData = $products->color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="dflex flex-column">
                                        <div class="color-product" style="background-color: <?php echo e($color->color); ?>;">
                                            </div>
                                            <p class="name-color"><?php echo e($color->color_name); ?></p>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- <div class="col-md-4 offset-md-1 bg-merah">
                    <h3>Kekurangan <?php echo e($products->name); ?></h3>
                    <ul>
                        <?php $__currentLoopData = $products->minus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kekurangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="merah"><?php echo e($kekurangan->kekurangan); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div> -->
            </div>
        </div>
    </div>
</div>
<div class="container">
    <h1 class="type-price">Harga dan Promo Type <?php echo e($products->name); ?></h1>
    <div class="product-price">
        <div class="d-flex flex-row flex-nowrap">
                <?php $__currentLoopData = $products->type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="catalog">
                    <div class="catalog-body">
                            <p class="type"><?php echo e($type->type); ?> | Rp. <?php echo e($type->price); ?> juta</p>
                        <?php $__currentLoopData = $type->down; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $down): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-between">
                            <p class="column">DP(Mulai Dari)</p>
                            <p class="price">Rp. <?php echo e($down->price_min); ?> juta</p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $down->credit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-between">
                            <p class="column">Angsuran</p>
                            <p class="price">Rp. <?php echo e($credit->price); ?> juta</p>
                        </div>
                        <div class="d-flex justify-content-between">
                            <div class="column">Tenor</div>
                            <p class="price"><?php echo e($credit->tenor); ?> months</p>
                        </div>
                        <div class="d-flex justify-content-center">
                        <a href="https://api.whatsapp.com/send?phone=+628881260028" class="text-danger">Promo Menarik</a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php echo $__env->make('layout/icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout/footercomp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\resources\views/product/show.blade.php ENDPATH**/ ?>