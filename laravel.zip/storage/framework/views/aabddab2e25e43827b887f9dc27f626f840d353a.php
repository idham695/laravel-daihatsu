<div class="d-flex flex-row flex-nowrap type-spec">
            <div class="card-type">
                <h4>PERFORMA</h4>
                <?php $__currentLoopData = $types->performance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $performance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-between body">
                        <div class="kolom">Mesin</div>
                        <strong><?php echo e($performance->machine_capacity); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between body">
                        <div class="kolom">Tenaga</div>
                        <strong><?php echo e($performance->horse_power); ?></strong>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="card-type">
                <h4>KESELAMATAN</h4>
                <?php $__currentLoopData = $types->keselamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keselamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-between body">
                        <div class="kolom">Sabuk Pengaman</div>
                        <strong><?php echo e($keselamatan->sabukPengaman); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between body">
                        <div class="kolom">Pengingat Pengaman</div>
                        <strong><?php echo e($keselamatan->pengingatPengaman); ?></strong>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
            <div class="card-type">
                <h4>KENYAMANAN</h4>
                <?php $__currentLoopData = $types->kenyamanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kenyamanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-between body">
                        <div class="kolom">Cruise Control</div>
                        <strong><?php echo e($kenyamanan->cruiseControl); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between body">
                        <div class="kolom">Pembuka Bagasi</div>
                        <strong><?php echo e($kenyamanan->pembukaBagasi); ?></strong>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="card-type">
                <h4>KAPASITAS</h4>
                <?php $__currentLoopData = $types->capacity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capacity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex justify-content-between body">
                    <div class="kolom">Berat Bersih</div>
                    <strong><?php echo e($capacity->berat_bersih); ?> kg</strong>
                </div>
                <div class="d-flex justify-content-between body">
                    <div class="kolom">Kapasitas Tangki</div>
                    <strong><?php echo e($capacity->kapasitas_tangki); ?> L</strong>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="angsur">
                <div class="angsuran">
                    <div class="card-type angsuran-front">
                        <h4>ANGSURAN</h4>
                        <?php $__currentLoopData = $types->down; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $down): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $down->credit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between body">
                                <div class="kolom">Durasi</div>
                                <strong><?php echo e($credit->tenor); ?> months</strong>
                            </div>
                            <div class="d-flex justify-content-between body">
                                <div class="kolom">Angsuran</div>
                                <strong><?php echo e($credit->price); ?> juta</strong>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="angsuran-back">
                        <div class="d-flex justify-content-center">
                            <a href="https://api.whatsapp.com/send?phone=+628881260028" class="button">Promo Menarik</a>
                        </div>
                    </div>
                </div>
            </div>
        </div><?php /**PATH C:\laravel\resources\views/layout/type/cardType.blade.php ENDPATH**/ ?>