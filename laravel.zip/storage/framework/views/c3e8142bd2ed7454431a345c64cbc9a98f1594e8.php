<div class="container">
            <div class="icon">
                <a href="https://api.whatsapp.com/send?phone=+628881260028" class="u"><img src="<?php echo e(URL::asset('img/whatsapp.png')); ?>" alt=""></a>
            </div>
</div><?php /**PATH C:\laravel\resources\views/layout/icon.blade.php ENDPATH**/ ?>