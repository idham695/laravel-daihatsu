<div class="teknical">
            <h3>Spesifikasi Teknik <?php echo e($types->product->name); ?> <?php echo e($types->type); ?></h3>
            <ul class="nav nav-tabs tab">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#performance">Performance</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#capacity">Kapasitas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#suspensi">Suspensi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#transmisi">Transmisi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#detailMesin">Detail Mesin</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#velg">Velg & Ban</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#kemudi">Kemudi</a>
                </li>
            </ul>
            <div class="tab-content content">
                    <div class="performance tab-pane active" id="performance">
                        <?php $__currentLoopData = $types->performance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $performance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <table class="table table-lg bg-light">
                                <thead>
                                    <tr>
                                        <th colspan="2">Performance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>kapasitas mesin</td>
                                        <td><?php echo e($performance->machine_capacity); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Tenaga</td>
                                        <td><?php echo e($performance->horse_power); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Torsi</td>
                                        <td><?php echo e($performance->torsi); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Jenis Bahan Bakar</td>
                                        <td><?php echo e($performance->fuel); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="capacity tab-pane fade" id="capacity">
                    <?php $__currentLoopData = $types->capacity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capacity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <table class="table table-lg bg-light">
                                <thead>
                                    <tr>
                                        <th colspan="2">Capacity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Kapasitas tempat duduk</td>
                                        <td><?php echo e($capacity->kapasitas_tempat_duduk); ?> orang</td>
                                    </tr>
                                    <tr>
                                        <td>kapasitas tangki</td>
                                        <td><?php echo e($capacity->kapasitas_tangki); ?> L</td>
                                    </tr>
                                    <tr>
                                        <td>Panjang</td>
                                        <td><?php echo e($capacity->panjang); ?> mm</td>
                                    </tr>
                                    <tr>
                                        <td>Lebar</td>
                                        <td><?php echo e($capacity->lebar); ?> mm</td>
                                    </tr>
                                    <tr>
                                        <td>Tinggi</td>
                                        <td><?php echo e($capacity->tinggi); ?> mm</td>
                                    </tr>
                                    <tr>
                                        <td>Jarak sumbu roda</td>
                                        <td><?php echo e($capacity->jarak_sumbu_roda); ?> mm</td>
                                    </tr>
                                    <tr>
                                        <td>Jarak Pijak Roda Depan</td>
                                        <td><?php echo e($capacity->jarak_pijak_roda_depan); ?> mm</td>
                                    </tr>
                                    <tr>
                                        <td>Jarak Pijak Roda Belakang</td>
                                        <td><?php echo e($capacity->jarak_pijak_roda_belakang); ?> mm</td>
                                    </tr>
                                    <tr>
                                        <td>Jumlah Pintu</td>
                                        <td><?php echo e($capacity->jumlah_pintu); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Berat Bersih</td>
                                        <td><?php echo e($capacity->berat_bersih); ?> kg</td>
                                    </tr>
                                </tbody>
                            </table>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="suspensi tab-pane fade" id="suspensi">
                    <?php $__currentLoopData = $types->suspensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suspensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <table class="table table-lg bg-light">
                                <thead>
                                    <tr>
                                        <th colspan="2">Suspensi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Suspensi depan</td>
                                        <td><?php echo e($suspensi->suspensi_depan); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Suspensi belakang</td>
                                        <td><?php echo e($suspensi->suspensi_belakang); ?></td>
                                    </tr>
                                </tbody>
                    </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="transmisi tab-pane fade" id="transmisi">
                    <?php $__currentLoopData = $types->transmisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transmisi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <table class="table table-lg bg-light">
                                <thead>
                                    <tr>
                                        <th colspan="2">Transmisi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Girboks</td>
                                        <td><?php echo e($transmisi->girbox); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Jenis Transmisi</td>
                                        <td><?php echo e($transmisi->transmisi); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Jenis Penggerak</td>
                                        <td><?php echo e($transmisi->penggerak); ?></td>
                                    </tr>
                                </tbody>
                    </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="detail tab-pane fade" id="detailMesin">
                    <?php $__currentLoopData = $types->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <table class="table table-lg bg-light">
                                <thead>
                                    <tr>
                                        <th colspan="2">Detail Mesin</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Jumlah Silinder</td>
                                        <td><?php echo e($detail->jumlah_silinder); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Katup per silinder</td>
                                        <td><?php echo e($detail->katup_per_silinder); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Konfigurasi katup</td>
                                        <td><?php echo e($detail->konfigurasi_katup); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Sistem suplai bahan bakar</td>
                                        <td><?php echo e($detail->suplai_bahan_bakar); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Mesin</td>
                                        <td><?php echo e($detail->mesin); ?></td>
                                    </tr>
                                </tbody>
                    </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="velg tab-pane fade" id="velg">
                    <?php $__currentLoopData = $types->velg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $velg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <table class="table table-lg bg-light">
                                <thead>
                                    <tr>
                                        <th colspan="2">Velg & Ban</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Ukuran Ban</td>
                                        <td><?php echo e($velg->ukuran); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Jenis Ban</td>
                                        <td><?php echo e($velg->jenis); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Ukuran Velg</td>
                                        <td><?php echo e($velg->ukuran_velg); ?></td>
                                    </tr>
                                </tbody>
                    </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="kemudi tab-pane fade" id="kemudi">
                    <?php $__currentLoopData = $types->kemudi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kemudi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <table class="table table-lg bg-light">
                                <thead>
                                    <tr>
                                        <th colspan="2">Kemudi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Steering Gear Type</td>
                                        <td><?php echo e($kemudi->steering_gear_type); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Radius Putas</td>
                                        <td><?php echo e($kemudi->radius_putar); ?> m</td>
                                    </tr>
                                </tbody>
                    </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
            </div>
</div>  <?php /**PATH C:\laravel\resources\views/layout/type/technical.blade.php ENDPATH**/ ?>