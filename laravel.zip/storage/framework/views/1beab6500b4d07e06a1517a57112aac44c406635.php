<?php $__env->startSection('title', "Dashboard"); ?>
<?php echo $__env->make('layout/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
        <div class="image">
                <div class="image-360">
                    <h3>Gambar 360 Daihatsu <?php echo e($products->name); ?></h3>
                                <div class="images">
                                    <!-- semua gambar yang dimasukan ke 360 harus sama -->
                                    <div
                                    <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    class="cloudimage-360"
                                    data-folder="<?php echo e(asset('/img/'.$images->name)); ?>"
                                    data-filename="/<?php echo e($images->name); ?>-{index}<?php echo e($images->extension); ?>"
                                    <?php $__currentLoopData = $count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    data-amount="<?php echo e($image->image_count); ?>"
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    data-speed=100
                                    style="cursor: ew-resize;"
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    >
                                    <!-- <button class="cloudimage-360-prev"></button>
                                    <button class="cloudimage-360-next"></button> -->
                                    </div>
                                </div>
                </div>
                <div class="interior">
                    <h3>Gallery gambar interior Daihatsu <?php echo e($products->name); ?></h3>
                        <?php $__currentLoopData = $products->interior; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img class = "photo" src="<?php echo e(asset('/img/interior/'. $image->image)); ?>" alt="">
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="eksterior">
                    <h3>Gallery gambar eksterior Daihatsu <?php echo e($products->name); ?></h3>
                        <?php $__currentLoopData = $products->eksterior; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <img class = "photo" src="<?php echo e(asset('/img/eksterior/'. $image->image)); ?>" alt="">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
        </div>
</div>

<?php echo $__env->make('layout/icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout/footercomp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\resources\views/product/getImage.blade.php ENDPATH**/ ?>